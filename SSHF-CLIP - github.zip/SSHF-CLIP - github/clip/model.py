from collections import OrderedDict
from typing import Tuple, Union

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn
import math
from clip.adaptor import Adaptor
from sklearn.cluster import KMeans 

def gaussian_kernel(size, sigma=2.0):
    
    x = torch.arange(size, dtype=torch.float32) - (size - 1) / 2
    y = torch.arange(size, dtype=torch.float32) - (size - 1) / 2
    x, y = torch.meshgrid(x, y, indexing='ij')
    
    kernel = torch.exp(-(x**2 + y**2) / (2 * sigma**2))
    kernel = kernel / kernel.sum()
    return kernel

class AdaptiveAggregation(nn.Module):
    def __init__(self, feature_dim=768, r_list=[1, 3, 5]):
        super().__init__()
        self.r_list = r_list
        self.gate_net = nn.Sequential(
            nn.Linear(feature_dim, 64),
            nn.ReLU(),
            nn.Linear(64, len(r_list)),
            nn.Softmax(dim=1)  
        )

    def forward(self, global_token):
        """
        global_token: [B, C]
        return: weights [B, 3]
        """
        weights = self.gate_net(global_token) 
        return weights

class GEGLU(nn.Module):
    def __init__(self, dim_in, dim_out):
        super().__init__()
        self.proj = nn.Linear(dim_in, dim_out * 2)

    def forward(self, x):
        x, gate = self.proj(x).chunk(2, dim=-1)
        return x * F.gelu(gate)

class FeedForward(nn.Module):
    def __init__(self, dim, dim_out=None, mult=4, glu=False, dropout=0.):
        super().__init__()
        inner_dim = int(dim * mult)
        if dim_out is None:
            dim_out = dim
        project_in = nn.Sequential(
            nn.Linear(dim, inner_dim),
            nn.GELU()
        ) if not glu else GEGLU(dim, inner_dim)

        self.net = nn.Sequential(
            project_in,
            nn.Dropout(dropout),
            nn.Linear(inner_dim, dim_out)
        )

    def forward(self, x):
        return self.net(x)

class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1):
        super().__init__()

        self.conv1 = nn.Conv2d(inplanes, planes, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.relu1 = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv2d(planes, planes, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.relu2 = nn.ReLU(inplace=True)

        self.avgpool = nn.AvgPool2d(stride) if stride > 1 else nn.Identity()

        self.conv3 = nn.Conv2d(planes, planes * self.expansion, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion)
        self.relu3 = nn.ReLU(inplace=True)

        self.downsample = None
        self.stride = stride

        if stride > 1 or inplanes != planes * Bottleneck.expansion:
            self.downsample = nn.Sequential(OrderedDict([
                ("-1", nn.AvgPool2d(stride)),
                ("0", nn.Conv2d(inplanes, planes * self.expansion, 1, stride=1, bias=False)),
                ("1", nn.BatchNorm2d(planes * self.expansion))
            ]))

    def forward(self, x: torch.Tensor):
        identity = x

        out = self.relu1(self.bn1(self.conv1(x)))
        out = self.relu2(self.bn2(self.conv2(out)))
        out = self.avgpool(out)
        out = self.bn3(self.conv3(out))

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu3(out)
        return out


class AttentionPool2d(nn.Module):
    def __init__(self, spacial_dim: int, embed_dim: int, num_heads: int, output_dim: int = None):
        super().__init__()
        self.positional_embedding = nn.Parameter(torch.randn(spacial_dim ** 2 + 1, embed_dim) / embed_dim ** 0.5)
        self.k_proj = nn.Linear(embed_dim, embed_dim)
        self.q_proj = nn.Linear(embed_dim, embed_dim)
        self.v_proj = nn.Linear(embed_dim, embed_dim)
        self.c_proj = nn.Linear(embed_dim, output_dim or embed_dim)
        self.num_heads = num_heads

    def forward(self, x):
        x = x.flatten(start_dim=2).permute(2, 0, 1)  
        x = torch.cat([x.mean(dim=0, keepdim=True), x], dim=0)  
        x = x + self.positional_embedding[:, None, :].to(x.dtype)  
        x, _ = F.multi_head_attention_forward(
            query=x[:1], key=x, value=x,
            embed_dim_to_check=x.shape[-1],
            num_heads=self.num_heads,
            q_proj_weight=self.q_proj.weight,
            k_proj_weight=self.k_proj.weight,
            v_proj_weight=self.v_proj.weight,
            in_proj_weight=None,
            in_proj_bias=torch.cat([self.q_proj.bias, self.k_proj.bias, self.v_proj.bias]),
            bias_k=None,
            bias_v=None,
            add_zero_attn=False,
            dropout_p=0,
            out_proj_weight=self.c_proj.weight,
            out_proj_bias=self.c_proj.bias,
            use_separate_proj_weight=True,
            training=self.training,
            need_weights=False
        )
        return x.squeeze(0)


class ModifiedResNet(nn.Module):
    """
    A ResNet class that is similar to torchvision's but contains the following changes:
    - There are now 3 "stem" convolutions as opposed to 1, with an average pool instead of a max pool.
    - Performs anti-aliasing strided convolutions, where an avgpool is prepended to convolutions with stride > 1
    - The final pooling layer is a QKV attention instead of an average pool
    """

    def __init__(self, layers, output_dim, heads, input_resolution=224, width=64):
        super().__init__()
        self.output_dim = output_dim
        self.input_resolution = input_resolution

       
        self.conv1 = nn.Conv2d(3, width // 2, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(width // 2)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(width // 2, width // 2, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(width // 2)
        self.relu2 = nn.ReLU(inplace=True)
        self.conv3 = nn.Conv2d(width // 2, width, kernel_size=3, padding=1, bias=False)
        self.bn3 = nn.BatchNorm2d(width)
        self.relu3 = nn.ReLU(inplace=True)
        self.avgpool = nn.AvgPool2d(2)

       
        self._inplanes = width  
        self.layer1 = self._make_layer(width, layers[0])
        self.layer2 = self._make_layer(width * 2, layers[1], stride=2)
        self.layer3 = self._make_layer(width * 4, layers[2], stride=2)
        self.layer4 = self._make_layer(width * 8, layers[3], stride=2)

        embed_dim = width * 32  
        self.attnpool = AttentionPool2d(input_resolution // 32, embed_dim, heads, output_dim)

    def _make_layer(self, planes, blocks, stride=1):
        layers = [Bottleneck(self._inplanes, planes, stride)]

        self._inplanes = planes * Bottleneck.expansion
        for _ in range(1, blocks):
            layers.append(Bottleneck(self._inplanes, planes))

        return nn.Sequential(*layers)

    def forward(self, x):
        def stem(x):
            x = self.relu1(self.bn1(self.conv1(x)))
            x = self.relu2(self.bn2(self.conv2(x)))
            x = self.relu3(self.bn3(self.conv3(x)))
            x = self.avgpool(x)
            return x

        x = x.type(self.conv1.weight.dtype)
        x = stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.attnpool(x)

        return x


class LayerNorm(nn.LayerNorm):
    """Subclass torch's LayerNorm to handle fp16."""

    def forward(self, x: torch.Tensor):
        orig_type = x.dtype
        ret = super().forward(x.type(torch.float32))
        return ret.type(orig_type)


class QuickGELU(nn.Module):
    def forward(self, x: torch.Tensor):
        return x * torch.sigmoid(1.702 * x)


class ResidualAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None):
        super().__init__()

        self.attn = nn.MultiheadAttention(d_model, n_head)
        self.ln_1 = LayerNorm(d_model)
        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))
        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x: torch.Tensor):
        x = x + self.attention(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x


class Transformer(nn.Module):
    def __init__(self, width: int, layers: int, heads: int, attn_mask: torch.Tensor = None):
        super().__init__()
        self.width = width
        self.layers = layers
        self.resblocks = nn.Sequential(*[ResidualAttentionBlock(width, heads, attn_mask) for _ in range(layers)])
        print("resblocks: ", len(self.resblocks))
        
    def forward(self, x: torch.Tensor, fearure_layers=None, visual_prompt=None):
        out = []
        prefix_len = len(visual_prompt) if visual_prompt is not None else 0
        for i in range(len(self.resblocks)):
            if i < prefix_len:
                x = torch.cat([visual_prompt[i:i+1].repeat(x.size(0), 1, 1), x], dim=1)
            x = self.resblocks[i](x)
            if i < prefix_len:
                x = x[:, visual_prompt[i:i+1].size(1):]
            if fearure_layers is not None and i+1 in fearure_layers:
                out.append(x)
        if fearure_layers is None:
            return x
        else:
            return out


class VisionTransformer(nn.Module):
    def __init__(self, input_resolution: int, patch_size: int, width: int, layers: int, heads: int, output_dim: int):
        super().__init__()
        self.input_resolution = input_resolution
        self.output_dim = output_dim
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=width, kernel_size=patch_size, stride=patch_size, bias=False)

        scale = width ** -0.5
        self.class_embedding = nn.Parameter(scale * torch.randn(width))
        self.positional_embedding = nn.Parameter(scale * torch.randn((input_resolution // patch_size) ** 2 + 1, width))
        self.ln_pre = LayerNorm(width)

        self.transformer = Transformer(width, layers, heads)

        self.ln_post = LayerNorm(width)
        self.proj = nn.Parameter(scale * torch.randn(width, output_dim))
        print(self.positional_embedding.size())

    
    def forward(self, x: torch.Tensor, feature_layers=[24], visual_prompt=None):
        x = self.conv1(x)  
        x = x.reshape(x.shape[0], x.shape[1], -1)  
        x = x.permute(0, 2, 1) 
        x = torch.cat([self.class_embedding.to(x.dtype) + torch.zeros(x.shape[0], 1, x.shape[-1], dtype=x.dtype, device=x.device), x], dim=1)  
        side = int((self.positional_embedding.shape[0] - 1) ** 0.5)
        new_side = int((x.shape[1] - 1) ** 0.5)

        
        if side != new_side:
            new_pos = self.positional_embedding[1:, :].reshape(-1, side, side, x.shape[-1]).permute(0, 3, 1, 2)
            new_pos = torch.nn.functional.interpolate(new_pos, (new_side, new_side), mode='bilinear')
            new_pos = new_pos.reshape(x.shape[-1], new_side * new_side).transpose(0, 1)
            self.positional_embedding.data = torch.cat([self.positional_embedding[:1, :], new_pos], 0)
            
        x = x + self.positional_embedding.to(x.dtype)
         
        if visual_prompt is not None:
            x = torch.cat([x, visual_prompt[:1].repeat(x.size(0), 1, 1)], dim=1)
        x = self.ln_pre(x)
        x = x.permute(1, 0, 2)  # NLD -> LND
        out = self.transformer(x, feature_layers)
        for i, o in enumerate(out):
            out[i] = o.permute(1, 0, 2)
            if visual_prompt is not None:
                out[i] = out[i][:, :-visual_prompt.size(1), :]
        return out

class HybridSemanticFusion(nn.Module):
    def __init__(self, k_clusters=20):
        super(HybridSemanticFusion, self).__init__()
        self.k_clusters = k_clusters
        self.cluster_performer = KMeans(n_clusters=self.k_clusters, n_init="auto")

    def forward(self, patch_tokens_list, anomaly_map):

        B, _, H, W = anomaly_map.size()
        flat_anomaly_map = anomaly_map.view(B, -1) 
        valid_tokens = [t[:, 1:, :] for t in patch_tokens_list] 
        avg_patch_tokens = torch.mean(torch.stack(valid_tokens, dim=0), dim=0) 

        batch_cluster_centers = []
        for b in range(B):
            feats = avg_patch_tokens[b].detach().cpu().numpy() # (L, C)
            cluster_labels = self.cluster_performer.fit_predict(feats)
            cluster_scores = {}
            amap_b = flat_anomaly_map[b] # (L)
            
            for label in range(self.k_clusters):
                indices = (cluster_labels == label)
                if indices.sum() > 0:
                    cluster_scores[label] = amap_b[indices].mean().item()
                else:
                    cluster_scores[label] = -1.0

            most_abnormal_label = max(cluster_scores, key=cluster_scores.get)
            
            indices = (cluster_labels == most_abnormal_label)
            indices_tensor = torch.from_numpy(indices).to(avg_patch_tokens.device)
            
            selected_feats = avg_patch_tokens[b][indices_tensor]
            centroid = selected_feats.mean(dim=0)
            batch_cluster_centers.append(centroid)

        semantic_rich_features = torch.stack(batch_cluster_centers, dim=0) 
        semantic_rich_features = F.normalize(semantic_rich_features, dim=1)
        
        return semantic_rich_features

class CLIP(nn.Module):
    def __init__(self,
                 embed_dim: int,
                 # vision
                 image_resolution: int,
                 vision_layers: Union[Tuple[int, int, int, int], int],
                 vision_width: int,
                 vision_patch_size: int,
                 # text
                 context_length: int,
                 vocab_size: int,
                 transformer_width: int,
                 transformer_heads: int,
                 transformer_layers: int
                 ):
        super().__init__()

        self.context_length = context_length

        if isinstance(vision_layers, (tuple, list)):
            vision_heads = vision_width * 32 // 64
            self.visual = ModifiedResNet(
                layers=vision_layers,
                output_dim=embed_dim,
                heads=vision_heads,
                input_resolution=image_resolution,
                width=vision_width
            )
        else:
            vision_heads = vision_width // 64
            self.visual = VisionTransformer(
                input_resolution=image_resolution,
                patch_size=vision_patch_size,
                width=vision_width,
                layers=vision_layers,
                heads=vision_heads,
                output_dim=embed_dim
            )

        self.transformer = Transformer(
            width=transformer_width,
            layers=transformer_layers,
            heads=transformer_heads,
            attn_mask=self.build_attention_mask()
        )

        self.vocab_size = vocab_size
        self.token_embedding = nn.Embedding(vocab_size, transformer_width)
        self.positional_embedding = nn.Parameter(torch.empty(self.context_length, transformer_width))
        self.ln_final = LayerNorm(transformer_width)

        self.text_projection = nn.Parameter(torch.empty(transformer_width, embed_dim))
        self.logit_scale = nn.Parameter(torch.ones([]) * np.log(1 / 0.07))

        self.initialize_parameters()

    def initialize_parameters(self):
        nn.init.normal_(self.token_embedding.weight, std=0.02)
        nn.init.normal_(self.positional_embedding, std=0.01)

        if isinstance(self.visual, ModifiedResNet):
            if self.visual.attnpool is not None:
                std = self.visual.attnpool.c_proj.in_features ** -0.5
                nn.init.normal_(self.visual.attnpool.q_proj.weight, std=std)
                nn.init.normal_(self.visual.attnpool.k_proj.weight, std=std)
                nn.init.normal_(self.visual.attnpool.v_proj.weight, std=std)
                nn.init.normal_(self.visual.attnpool.c_proj.weight, std=std)

            for resnet_block in [self.visual.layer1, self.visual.layer2, self.visual.layer3, self.visual.layer4]:
                for name, param in resnet_block.named_parameters():
                    if name.endswith("bn3.weight"):
                        nn.init.zeros_(param)

        proj_std = (self.transformer.width ** -0.5) * ((2 * self.transformer.layers) ** -0.5)
        attn_std = self.transformer.width ** -0.5
        fc_std = (2 * self.transformer.width) ** -0.5
        for block in self.transformer.resblocks:
            nn.init.normal_(block.attn.in_proj_weight, std=attn_std)
            nn.init.normal_(block.attn.out_proj.weight, std=proj_std)
            nn.init.normal_(block.mlp.c_fc.weight, std=fc_std)
            nn.init.normal_(block.mlp.c_proj.weight, std=proj_std)

        if self.text_projection is not None:
            nn.init.normal_(self.text_projection, std=self.transformer.width ** -0.5)

    def build_attention_mask(self):
        mask = torch.empty(self.context_length, self.context_length)
        mask.fill_(float("-inf"))
        mask.triu_(1)  # zero out the lower diagonal
        return mask

    @property
    def dtype(self):
        return self.visual.conv1.weight.dtype
    
    
    def insert(self, args, tokenizer, device):
        self.args = args 
        
        self.normal_cls_prompt = f'without defect.'
        self.anomaly_cls_prompt = f'with defect.'
        self.state_prompt_tokens = tokenizer([self.normal_cls_prompt, self.anomaly_cls_prompt]).to(device)
        self.tokenizer = tokenizer
        self.device = device
        self.prompt_len = args.prompt_len
        
        self.state_prompt_embedding = nn.Parameter(torch.empty(1, args.prompt_len, self.token_embedding.weight.shape[-1]).to(device))
        nn.init.normal_(self.state_prompt_embedding, std=0.01)
        self.state_prompt_embedding.requires_grad_(True)
        
        self.adaptor = Adaptor(inplanes=self.visual.proj.shape[0], outplanes=self.visual.proj.shape[0]).to(device)
        
        if getattr(args, 'use_SGSS', 0):
            self.learnable_proj = nn.Linear(self.visual.proj.shape[0], self.visual.proj.shape[1], bias=False).to(device)
            with torch.no_grad():
                self.learnable_proj.weight.copy_(self.visual.proj.t())
        
        if getattr(args, 'use_dynamic_prompt', 0):
            embed_dim = self.token_embedding.weight.shape[-1] # C_text
            visual_dim = self.visual.proj.shape[0] # 1024 for ViT-L
            self.dynamic_prompt_generator = nn.Linear(visual_dim, args.prompt_len * embed_dim).to(device)
            nn.init.zeros_(self.dynamic_prompt_generator.weight)
            nn.init.zeros_(self.dynamic_prompt_generator.bias)

        if getattr(args, 'use_GSFM', 0):
            k_clusters = getattr(args, 'hsf_k', 20) 
            self.hsf = HybridSemanticFusion(k_clusters=k_clusters).to(device)

        if hasattr(self.visual, 'proj') and self.visual.proj is not None:
            embed_dim = self.visual.proj.shape[0] 
        elif hasattr(self.visual, 'attnpool'):
            embed_dim = self.visual.attnpool.c_proj.in_features
        else:
            embed_dim = self.visual.output_dim

        self.adaptive_agg = AdaptiveAggregation(feature_dim=embed_dim, r_list=[1, 3, 5]).to(device)
        
        self.memorybank = None
        self.memory_backbone = None
        self.gaussian_kernel = {'3': gaussian_kernel(size=3, sigma=4).to(device), '5': gaussian_kernel(size=5, sigma=4).to(device)}
    
         
    
    def encode_state_prompt(self, dynamic_vector=None):
        state_x = self.token_embedding(self.state_prompt_tokens).type(self.dtype)
        
        if dynamic_vector is not None:
            batch_size = dynamic_vector.shape[0]
            
            static_prompt = self.state_prompt_embedding.expand(batch_size, -1, -1)
            hybrid_prompt = static_prompt + dynamic_vector.type(self.dtype)
            state_x_expanded = state_x.unsqueeze(0).expand(batch_size, -1, -1)
            state_x_flat = state_x_expanded.reshape(batch_size * 2, -1, state_x.shape[-1])
            hybrid_prompt_flat = hybrid_prompt.repeat_interleave(2, dim=0)
            input_embedding = torch.cat([hybrid_prompt_flat, state_x_flat], dim=1)[:, :77, :]
            current_batch_size = batch_size * 2
            
        else:
            input_embedding = torch.cat([self.state_prompt_embedding.repeat(2, 1, 1), state_x], dim=1)[:, :77, :]
            current_batch_size = 2
        x = input_embedding + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  
        x = self.ln_final(x).type(self.dtype)
        if dynamic_vector is not None:
            idx = self.prompt_len + self.state_prompt_tokens.argmax(dim=-1)
            idx = idx.repeat(batch_size) 
            
            x = x[torch.arange(current_batch_size), idx] @ self.text_projection
            x = x.view(batch_size, 2, -1)
        else:
            x = x[torch.arange(current_batch_size), self.prompt_len + self.state_prompt_tokens.argmax(dim=-1)] @ self.text_projection

        return x
    
    

    def get_trainable_parameters(self):
        params = [self.state_prompt_embedding] + list(self.adaptor.parameters())
        
        if hasattr(self, 'learnable_proj'):
            params += list(self.learnable_proj.parameters())
            
        if hasattr(self, 'dynamic_prompt_generator'):
            params += list(self.dynamic_prompt_generator.parameters())

        if hasattr(self, 'adaptive_agg'):
            params += list(self.adaptive_agg.parameters())
            
        return params
    

    def encode_text(self, text):
        x = self.token_embedding(text).type(self.dtype)  
        x = x + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  
        x = self.ln_final(x).type(self.dtype)
        x = x[torch.arange(x.shape[0]), text.argmax(dim=-1)] @ self.text_projection
        return x
    
    def encode_state_prompt(self, dynamic_vector=None):
        state_x = self.token_embedding(self.state_prompt_tokens).type(self.dtype)
        
        if dynamic_vector is not None:
            batch_size = dynamic_vector.shape[0]
            static_prompt = self.state_prompt_embedding.expand(batch_size, -1, -1)
            hybrid_prompt = static_prompt + dynamic_vector.type(self.dtype)
            state_x = state_x.unsqueeze(0).expand(batch_size, -1, -1, -1)
            state_x = state_x.reshape(batch_size * 2, -1, state_x.shape[-1]) 
            hybrid_prompt = hybrid_prompt.repeat_interleave(2, dim=0)  
            input_embedding = torch.cat([hybrid_prompt, state_x], dim=1)[:, :77, :]
        else:
            state_x = torch.cat([self.state_prompt_embedding.repeat(2, 1, 1), state_x], dim=1)[:, :77, :]
            input_embedding = state_x


        x = input_embedding + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  
        x = x.permute(1, 0, 2)  
        x = self.ln_final(x).type(self.dtype)
        

        if dynamic_vector is not None:
             idx = self.prompt_len + self.state_prompt_tokens.argmax(dim=-1) 
             idx = idx.repeat(batch_size) 
             x = x[torch.arange(x.shape[0]), idx] @ self.text_projection
             x = x.view(batch_size, 2, -1)
        else:
             x = x[torch.arange(x.shape[0]), self.prompt_len + self.state_prompt_tokens.argmax(dim=-1)] @ self.text_projection

        return x
    
    def encode_image(self, image, feature_layers=None):
        return self.visual(image.type(self.dtype), feature_layers)
    
    def aggerate_neighbor(self, x, patchsize, stride=1):
        if patchsize == 1:
            return x
        cls_token = x[:, :1, :]
        x = x[:, 1:, :]
        padding = patchsize // 2
        b, l, c = x.size()
        h = w = int(math.sqrt(l))
        x = x.reshape(b, h, w, c).permute(0, 3, 1, 2)
        
        x = torch.nn.functional.unfold(x, kernel_size=patchsize, padding=padding, stride=stride) 
        x = x.permute(0, 2, 1).reshape(-1, c, patchsize * patchsize).permute(0, 2, 1) 
        kernel = self.gaussian_kernel[str(patchsize)].reshape(1, patchsize * patchsize, 1)
        x = torch.sum(x * kernel, dim=1).reshape(b, l, c)
        x = torch.cat([cls_token, x], dim=1)
        return x
    
    
    def aggerate_neighbors(self, img_tokens):
        img_token_list = []
        for img_token in img_tokens:
            for r in [1, 3, 5]:
                new_img_token = self.aggerate_neighbor(img_token, r)
                img_token_list.append(new_img_token)
        return img_token_list
    
    
    def detect_encode_image(self, image, args):
        raw_img_tokens_list = self.encode_image(image, args.feature_layers) 
        global_feat = raw_img_tokens_list[-1][:, 0, :] # Shape: (B, C)

        img_tokens = self.aggerate_neighbors(raw_img_tokens_list)

        output_tokens = []
        for img_token in img_tokens:
            x = self.visual.ln_post(self.adaptor(img_token))
            if getattr(args, 'use_SGSS', 0) and hasattr(self, 'learnable_proj'):
                x = self.learnable_proj(x)
            else:
                x = x @ self.visual.proj
            
            output_tokens.append(x)
            
        return output_tokens, global_feat
    
    
    
    def store_memory(self, image, args):
        img_tokens = self.encode_image(image, args.memory_layers)
        img_tokens = self.aggerate_neighbors(img_tokens)
        b, l, c = img_tokens[0].size()
        self.memorybank = [torch.nn.functional.normalize(img_token[:, 1:], dim=-1).reshape(-1, c) for img_token in img_tokens]
      
    def detect_forward_seg(self, image, args):
        img_tokens, global_feat_raw = self.detect_encode_image(image, args)
        if hasattr(self, 'adaptive_agg'):
            gate_weights = self.adaptive_agg(global_feat_raw.type(self.dtype))
        else:
            gate_weights = None

        dynamic_vector = None
        if getattr(args, 'use_dynamic_prompt', 0) and hasattr(self, 'dynamic_prompt_generator'):
            dynamic_vector = self.dynamic_prompt_generator(global_feat_raw)
            dynamic_vector = dynamic_vector.view(global_feat_raw.shape[0], self.prompt_len, -1)

        text_features = self.encode_state_prompt(dynamic_vector)
        text_features = torch.nn.functional.normalize(text_features, dim=-1)
        scores = 0
        anomaly_maps_list = []
        for i, img_token in enumerate(img_tokens):
            img_token_norm = torch.nn.functional.normalize(img_token, dim=-1)
            
            if text_features.dim() == 3: 
                score = torch.matmul(img_token_norm, text_features.permute(0, 2, 1)) / 0.07
            else:
                score = torch.matmul(img_token_norm, text_features.t()) / 0.07
            if gate_weights is not None:
                w = gate_weights[:, i % 3].view(-1, 1, 1)
                scores += score * w
            else:
                scores += score

            prob_layer = torch.softmax(score, dim=-1)
            anomaly_maps_list.append(prob_layer[:, 1:, 1]) 

        prob = torch.softmax(scores, dim=-1) 
        
        cls_score_origin = prob[:, 0, 1].view(-1)

        if getattr(args, 'use_GSFM', 0) and hasattr(self, 'hsf'):
            patch_tokens_only = [t[:, 1:, :] for t in img_tokens]
            
            b_sz, l_sz = patch_tokens_only[0].shape[:2]
            h = w = int(math.sqrt(l_sz))
            formatted_maps = [m.reshape(b_sz, 1, h, w) for m in anomaly_maps_list]
            
            avg_anomaly_map = torch.stack(formatted_maps, dim=1).mean(dim=1) 
            
            semantic_rich_feat = self.hsf(img_tokens, avg_anomaly_map) 
            semantic_rich_feat = F.normalize(semantic_rich_feat, dim=-1)
            
            if text_features.dim() == 3:
                abnormal_text_feat = text_features[:, 1, :].unsqueeze(2) 
                img_logits = torch.bmm(semantic_rich_feat.unsqueeze(1), abnormal_text_feat).squeeze(2).squeeze(1)
            else:
                abnormal_text_feat = text_features[1, :] 
                img_logits = torch.matmul(semantic_rich_feat, abnormal_text_feat)
            
            hsf_score = torch.sigmoid(img_logits / 0.07)
            global_feat_adapted = torch.stack([t[:, 0, :] for t in img_tokens], dim=0).mean(dim=0) 
            global_feat_norm = F.normalize(global_feat_adapted, dim=-1)
            similarity = torch.sum(semantic_rich_feat * global_feat_norm, dim=-1) 
            alpha = (1 - similarity)**2
            alpha = alpha.view(-1) 
            cls_label = (1 - alpha) * cls_score_origin + alpha * hsf_score
            
        else:
            cls_label = cls_score_origin

        predict_map = prob[:, 1:, 1]
        b, l = predict_map.size()
        h = w = int(math.sqrt(l))
        predict_map = predict_map.reshape(b, 1, h, w)
        
        return cls_label, predict_map, img_tokens
    
        
    
    def detect_forward_memorybank(self, image, args):
        scores = 0
        img_tokens = self.encode_image(image, args.memory_layers)
        img_tokens = self.aggerate_neighbors(img_tokens)
        for i, img_token in enumerate(img_tokens):
            img_token = torch.nn.functional.normalize(img_token, dim=-1)
            score = (1 - torch.matmul(img_token, self.memorybank[i].T)) .min(dim=-1)[0] / 2
            scores += score[:, 1:]
        scores = scores / len(img_tokens)
        cls_label = torch.max(scores, dim=-1)[0]
        b, l = scores.size()
        h = w = int(math.sqrt(l))
        predict_map = scores.reshape(b, 1, h, w)
        return cls_label, predict_map
    
    
    
    def detect_forward(self, image, args):
        cls_label, predict_map, _= self.detect_forward_seg(image, args)
        if self.memorybank is not None:
            cls_label_memory, predict_map_memory = self.detect_forward_memorybank(image, args)
            predict_map = predict_map_memory + args.alpha * predict_map
            cls_label = cls_label_memory + args.alpha * cls_label
        return cls_label, predict_map
    

    def forward(self, image, text):
        image_features = self.encode_image(image)
        if isinstance(image_features, (list, tuple)):
            image_features = image_features[0]
        text_features = self.encode_text(text)
        if isinstance(text_features, (list, tuple)):
            text_features = text_features[0]

        # normalized features
        image_features = image_features / image_features.norm(dim=1, keepdim=True)
        text_features = text_features / text_features.norm(dim=1, keepdim=True)

        # cosine similarity as logits
        logit_scale = self.logit_scale.exp()
        logits_per_image = logit_scale * image_features @ text_features.t()
        logits_per_text = logits_per_image.t()

        # shape = [global_batch_size, global_batch_size]
        return logits_per_image, logits_per_text


def convert_weights(model: nn.Module):
    """Convert applicable model parameters to fp16"""

    def _convert_weights_to_fp16(l):
        if isinstance(l, (nn.Conv1d, nn.Conv2d, nn.Linear)):
            l.weight.data = l.weight.data.half()
            if l.bias is not None:
                l.bias.data = l.bias.data.half()

        if isinstance(l, nn.MultiheadAttention):
            for attr in [*[f"{s}_proj_weight" for s in ["in", "q", "k", "v"]], "in_proj_bias", "bias_k", "bias_v"]:
                tensor = getattr(l, attr)
                if tensor is not None:
                    tensor.data = tensor.data.half()

        for name in ["text_projection", "proj"]:
            if hasattr(l, name):
                attr = getattr(l, name)
                if attr is not None:
                    attr.data = attr.data.half()

    model.apply(_convert_weights_to_fp16)


def build_model(state_dict: dict):
    vit = "visual.proj" in state_dict

    if vit:
        vision_width = state_dict["visual.conv1.weight"].shape[0]
        vision_layers = len([k for k in state_dict.keys() if k.startswith("visual.") and k.endswith(".attn.in_proj_weight")])
        vision_patch_size = state_dict["visual.conv1.weight"].shape[-1]
        grid_size = round((state_dict["visual.positional_embedding"].shape[0] - 1) ** 0.5)
        image_resolution = vision_patch_size * grid_size
    else:
        counts: list = [len(set(k.split(".")[2] for k in state_dict if k.startswith(f"visual.layer{b}"))) for b in [1, 2, 3, 4]]
        vision_layers = tuple(counts)
        vision_width = state_dict["visual.layer1.0.conv1.weight"].shape[0]
        output_width = round((state_dict["visual.attnpool.positional_embedding"].shape[0] - 1) ** 0.5)
        vision_patch_size = None
        assert output_width ** 2 + 1 == state_dict["visual.attnpool.positional_embedding"].shape[0]
        image_resolution = output_width * 32

    embed_dim = state_dict["text_projection"].shape[1]
    context_length = state_dict["positional_embedding"].shape[0]
    vocab_size = state_dict["token_embedding.weight"].shape[0]
    transformer_width = state_dict["ln_final.weight"].shape[0]
    transformer_heads = transformer_width // 64
    transformer_layers = len(set(k.split(".")[2] for k in state_dict if k.startswith("transformer.resblocks")))

    model = CLIP(
        embed_dim,
        image_resolution, vision_layers, vision_width, vision_patch_size,
        context_length, vocab_size, transformer_width, transformer_heads, transformer_layers
    )

    for key in ["input_resolution", "context_length", "vocab_size"]:
        if key in state_dict:
            del state_dict[key]

    model.load_state_dict(state_dict)
    return model.eval()
